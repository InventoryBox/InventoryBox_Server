module.exports={
    secretKey:'SeCrEtKeY4HaShInG!',
    options:{
        algorithm:"HS256",
        expiresIn:"6h",
        issuer:"our-sopt"
    }
}