const KakaoStrategy = require("passport-kakao").Strategy;
const passport = require('passport')
const kakaoKey = {
  clientID: "f2b9994d9bfb483c6b5b6027e1396335",
  clientSecret: "5obudDVUdd9SFCTYvck5lh9zl9EiRIi8",
  callbackURL: "http://localhost:3000/kakao/callback"
};


passport.use(
  "kakao-login",
  new KakaoStrategy(kakaoKey, (accessToken, refreshToken, profile, done) => {
    console.log(profile);
  })
);

module.exports={
  passport,kakaoKey
}