const nodemailer = require('nodemailer');

var generateRandom = function (min, max) {
    var ranNum = Math.floor(Math.random()*(max-min+1)) + min;
    return ranNum;
  }
  
  const number = generateRandom(111111,999999)

const smtpTransport = nodemailer.createTransport({
    service: "Gmail",
    auth: {
        user: "gudwnsrh@gmail.com",
        pass: "worhckdrhdlatl"
    },
    tls: {
        rejectUnauthorized: false
    }
  });

  module.exports={
      smtpTransport,
      number
  }