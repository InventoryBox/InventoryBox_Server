const mysql = require('promise-mysql');


const config = {
    host : 'db-out-sopt.ch1x1cy0infe.ap-northeast-2.rds.amazonaws.com',
    port : 3306,
    user : 'admin',
    password : 'worhckdrhtjqj',
    database : 'InventoryBox'
}

module.exports = mysql.createPool(config)